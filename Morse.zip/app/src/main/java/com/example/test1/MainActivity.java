package com.example.test1;

        import androidx.appcompat.app.AppCompatActivity;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText UserTextET;
    Button button;
    TextView itog;
    String UserTextMorse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupUI();
    }

    public void click(View view) {
        String UserText = UserTextET.getText().toString();
        UserTextMorse = UserText
                .replace("a", " ·− ").replace("A", " ·− ")
                .replace("а", " ·− ").replace("А", " ·− ")
                .replace("b", " −··· ").replace("B", " −··· ")
                .replace("б", " −··· ").replace("Б", " −··· ")
                .replace("w", " ·−− ").replace("W", " ·−− ")
                .replace("в", " ·−− ").replace("В", " ·−− ")
                .replace("g", " −−· ").replace("G", " −−· ")
                .replace("г", " −−· ").replace("Г", " −−· ")
                .replace("d", " −·· ").replace("D", " −·· ")
                .replace("д", " −·· ").replace("Д", " −·· ")
                .replace("e", " · ").replace("E", " · ")
                .replace("е", " · ").replace("Е", " · ")
                .replace("ё", " · ").replace("Ё", " · ")
                .replace("v", " ···− ").replace("V", " ···− ")
                .replace("ж", " ···− ").replace("Ж", " ···− ")
                .replace("z", " −−·· ").replace("Z", " −−·· ")
                .replace("з", " −−·· ").replace("З", " −−·· ")
                .replace("i", " ·· ").replace("I", " ·· ")
                .replace("и", " ·· ").replace("И", " ·· ")
                .replace("j", " ·−−− ").replace("J", " ·−−− ")
                .replace("й", " ·−−− ").replace("Й", " ·−−− ")
                .replace("k", " −·− ").replace("K", " −·− ")
                .replace("к", " −·− ").replace("К", " −·− ")
                .replace("l", " ·−·· ").replace("L", " ·−·· ")
                .replace("л", " ·−·· ").replace("Л", " ·−·· ")
                .replace("m", " −− ").replace("M", " −− ")
                .replace("м", " −− ").replace("М", " −− ")
                .replace("n", " −· ").replace("N", " −· ")
                .replace("н", " −· ").replace("Н", " −· ")
                .replace("o", " −−− ").replace("O", " −−− ")
                .replace("о", " −−− ").replace("О", " −−− ")
                .replace("p", " ·−−· ").replace("P", " ·−−· ")
                .replace("п", " ·−−· ").replace("П", " ·−−· ")
                .replace("r", " ·−· ").replace("R", " ·−· ")
                .replace("р", " ·−· ").replace("Р", " ·−· ")
                .replace("s", " ··· ").replace("S", " ··· ")
                .replace("с", " ··· ").replace("С", " ··· ")
                .replace("t", " − ").replace("T", " − ")
                .replace("т", " − ").replace("Т", " − ")
                .replace("u", " ··− ").replace("U", " ··− ")
                .replace("у", " ··− ").replace("У", " ··− ")
                .replace("f", " ··−· ").replace("F", " ··−· ")
                .replace("ф", " ··−· ").replace("Ф", " ··−· ")
                .replace("h", " ···· ").replace("H", " ···· ")
                .replace("х", " ···· ").replace("Х", " ···· ")
                .replace("c", " −·−· ").replace("C", " −·−· ")
                .replace("ц", " −·−· ").replace("Ц", " −·−· ")
                .replace("ч", " −−−· ").replace("Ч", " −−−· ")
                .replace("ш", " −−−− ").replace("Ш", " −−−− ")
                .replace("q", " −−·− ").replace("Q", " −−·− ")
                .replace("щ", " −−·− ").replace("Щ", " −−·− ")
                .replace("ъ", " −−·−− ").replace("Ъ", " −−·−− ")
                .replace("ы", " −·−− ").replace("Ы", " −·−− ")
                .replace("y", " −·−− ").replace("Y", " −·−− ")
                .replace("ь", " −··− ").replace("Ь", " −··− ")
                .replace("x", " −··− ").replace("X", " −··− ")
                .replace("э", " ··−·· ").replace("Э", " ··−·· ")
                .replace("ю", " ··−− ").replace("Ю", " ··−− ")
                .replace("я", " ·−·− ").replace("Я", " ·−·− ")
                .replace("1", " ·−−−− ").replace("2", " ··−−− ")
                .replace("3", " ···−− ").replace("4", " ····− ")
                .replace("5", " ····· ").replace("6", " −···· ")
                .replace("7", " −−··· ").replace("8", " −−−·· ")
                .replace("9", " −−−−· ").replace("0", " −−−−− ")
                .replace(".", " ······ ").replace(",", " ·−·−·− ")
                .replace(":", " −−−··· ").replace(";", " −·−·−· ")
                .replace("(", " −·−−· ").replace(")", " −·−−·− ")
                .replace("'", " ·−−−−· ").replace("\"", " ·−··−· ")
                .replace("-", " −····− ").replace("/", " −··−· ")
                .replace("_", " ··−−·− ").replace("?", " ··−−·· ")
                .replace("!", " −−··−− ").replace("+", " ·−·−· ")
                .replace("§", " −···− ").replace("¶", " ·−·−· ")
                .replace("@", " ·−−·−· ");
        itog.setText(UserTextMorse);
        Toast.makeText(this, UserTextMorse, Toast.LENGTH_SHORT).show();
    }

    private void setupUI(){
        UserTextET =  findViewById(R.id.your_text);
        button = findViewById(R.id.button);
        itog = findViewById(R.id.itog);
    }

}